//
//  SegueIdentifiers.swift
//  Zootastic
//
//  Created by Andrew Bancroft on 5/27/15.
//  Copyright (c) 2015 Andrew Bancroft. All rights reserved.
//

import Foundation

public enum SegueIdentifiers: String {
	case AnimalEditorSegue = "AnimalEditorSegue"
}